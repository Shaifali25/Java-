public interface Interface {
    void openAccount(int i);
    void showAccount();
    void deposit();
    void withdrawal();
    boolean search(String ac_no);
    void withdrawfee();
}
