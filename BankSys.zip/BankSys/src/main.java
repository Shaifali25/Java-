import java.util.Scanner;
public class main {
    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("---------------------------------------------------------------------");
        System.out.println("** CREATING INITIAL ACCOUNTS TO PERFORM BANKING OPERATIONS ON THEM **");
        System.out.println("---------------------------------------------------------------------");
        System.out.print("How many number of customers do you want to input? ( Please enter numeric values only ) : ");
            int n = sc.nextInt();
            sbi arr[] = new sbi[n];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = new sbi();
                arr[i].openAccount(i);
                System.out.println();
            }
            int ch;
            do {
                System.out.println("\n *** Welcome to State Bank of India ***");
                System.out.println(" 1. Display all account details \n 2. Search by Account number\n 3. Deposit the amount \n 4. Withdraw the amount \n 5. Transfer Amount \n 6. Exit  ");
                System.out.println("Enter your choice: ");
                ch = sc.nextInt();
                switch (ch) {
                    case 1:
                        for (int i = 0; i < arr.length; i++) {
                            arr[i].showAccount();
                            System.out.println();
                        }
                        break;
                    case 2:
                        System.out.print("Enter account no. you want to search: ");
                        String ac_no = sc.next();
                        boolean found = false;
                        for (int i = 0; i < arr.length; i++) {
                            found = arr[i].search(ac_no);
                            if (found) {
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Search failed! Account doesn't exist..!!");
                        }
                        break;
                    case 3:
                        System.out.print("Enter Account no. : ");
                        ac_no = sc.next();
                        found = false;
                        for (int i = 0; i < arr.length; i++) {
                            found = arr[i].search(ac_no);
                            if (found) {
                                arr[i].deposit();
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Search failed! Account doesn't exist..!!");
                        }
                        break;
                    case 4:
                        System.out.print("Enter Account No : ");
                        ac_no = sc.next();
                        found = false;
                        for (int i = 0; i < arr.length; i++) {
                            found = arr[i].search(ac_no);
                            if (found) {
                                arr[i].withdrawal();
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Search failed! Account doesn't exist..!!");
                        }
                        break;

                    case 5:
                        double trans = 0;
                        System.out.print("Enter Account No from which you want to transfer amount : ");
                        ac_no = sc.next();
                        found = false;
                        for (int i = 0; i < arr.length; i++) {
                            found = arr[i].search(ac_no);
                            if (found) {
                                System.out.print("Enter Amount you want to transfer (in Rs.): ");
                                trans = sc.nextDouble();
                                if (arr[i].balance < trans) {
                                    System.out.println("Insufficient Balance..Couldn't transfer");
                                    break;
                                }
                                System.out.print("Enter Account no. to transfer amount : ");
                                ac_no = sc.next();
                                found = false;
                                for (int j = 0; j < arr.length; j++) {
                                    found = arr[j].search(ac_no);
                                    if (found) {
                                        arr[i].balance = arr[i].balance - trans;
                                        arr[j].balance = arr[j].balance + trans;
                                        System.out.println(trans + " Rs. Successfully Transferred  !!!");
                                        break;
                                    } else if (j == arr.length - 1 && found == false) {
                                        System.out.print("Search failed! Account doesn't exist..!!");
                                        break;
                                    }
                                }
                                break;
                            } else if (i == arr.length - 1 && found == false) {
                                System.out.print("Search failed! Account doesn't exist..!!");
                                break;
                            }
                        }
                    case 6:
                        System.out.println("Thank you...");
                        break;
                    default:
                        System.out.println("Please Enter Choice within 1-6 only");
                }
            } while (ch != 6);
        }
}
