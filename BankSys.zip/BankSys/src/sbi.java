import java.util.Scanner;
class sbi implements Interface {
    private String accno="";
    private String name;
    private double fee=0.0;
    private String acc_type;
    public double balance;
    Scanner sc = new Scanner(System.in);

    public void openAccount(int i) {
        System.out.print("Enter your name: ");
        name = sc.nextLine();
        if(!(name.matches("^[a-zA-Z]*$"))){
            System.out.println("Account holder Name can't be numeric or special characters");
            System.out.print("Please Re-enter your name (in alphabets only) : ");
            name = sc.nextLine();
        }
        System.out.print("Enter account type ( Savings / Current / FD): ");
        acc_type = sc.next();
        if(acc_type.equalsIgnoreCase("Savings")||acc_type.equalsIgnoreCase("Current")||acc_type.equalsIgnoreCase("FD")){
            System.out.print("Enter Balance ( in Rs. ): ");
            balance = sc.nextDouble();
            if(balance<2500){
                System.out.println("Account can't be created since minimum balance is less than 2500/-");
                System.out.print("Please Re-Enter initial balance (>= Rs.2500) : ");
                balance = sc.nextDouble();
                accno = "1000";
                accno += i;
                System.out.println("Account no. assigned to you is : " + accno);
            }
            else {
                accno = "1000";
                accno += i;
                System.out.println("Account no. assigned to you is : " + accno);
            }
        }
        else{
            System.out.println("Invalid Account Type !!!\n");
            System.out.print("Please RE-enter account type ( Savings / Current / FD): ");
            acc_type = sc.next();
            if(acc_type.equalsIgnoreCase("Savings")||acc_type.equalsIgnoreCase("Current")||acc_type.equalsIgnoreCase("FD")){
                System.out.print("Enter Balance ( in Rs. ): ");
                balance = sc.nextDouble();
                if(balance<2500){
                    System.out.println("Account can't be created since minimum balance is less than 2500/-");
                    System.out.print("Please Re-Enter initial balance (>= Rs.2500) : ");
                    balance = sc.nextDouble();
                    accno = "1000";
                    accno += i;
                    System.out.println("Account no. assigned to you is : " + accno);
                }else {
                    accno = "1000";
                    accno += i;
                    System.out.println("Account no. assigned to you is : " + accno);
                }
            }
        }
    }



    //method to display account details
    public void showAccount() {
        if(!(accno.equals(""))){
            System.out.println("Name of account holder: " + name);
            System.out.println("Account no.: " + accno);
            System.out.println("Account type: " + acc_type);
            System.out.println("Balance: Rs. " + balance);
        }

    }
    public void deposit() {
        double amt;
        System.out.println("Enter the amount you want to deposit: ");
        amt = sc.nextDouble();//1500
        balance = balance + amt;
        System.out.println("Balance after depositing Rs. "+amt+": Rs. " + balance);
    }
    public void withdrawal() {
        double amt;
        System.out.println("Enter the amount you want to withdraw: ");
        amt = sc.nextDouble();
        withdrawfee();
        System.out.println("Withdrawl fee applied = Rs. "+fee);
        amt=amt+fee;
        if (balance >= amt) {
            balance = balance - amt;
            System.out.println("Balance after withdrawing Rs. "+amt+" : Rs. " + balance);
        } else {
            System.out.println("Your balance is less than Rs. " + amt + "\nTransaction failed...!!" );
        }
    }
    public boolean search(String ac_no) {
        if (accno.equals(ac_no)) {
            showAccount();
            System.out.println();
            return (true);
        }
        return (false);
    }
    public void withdrawfee() {
        if(acc_type.equalsIgnoreCase("Savings")){
            fee=2.05;
        }
        else if(acc_type.equalsIgnoreCase("current")){
            fee=1.375;
        }
        else if(acc_type.equalsIgnoreCase("FD")){
            fee=2.34;
        }
    }
}
